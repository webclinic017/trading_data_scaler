
# Change Log
All notable changes to this project will be documented in this file.
## v4.0.0 - 2021-12-07

  Bug fix - error in github python module dependencies
## v3.1.0 - 2021-12-07

  Add feature - new usdjpy_15_min_correlation_trading strategy
## v3.0.0 - 2021-11-24

  maintenance - update python dependencies

## v2.0.0 - 2021-08-08

  fix bug change package name from sqlconnection to sqlserverconnection due to redundant python package
  
## v1.1.0 - 2021-08-08
 
  Intial release

